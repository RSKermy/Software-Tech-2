import time
import random
import string
import tkinter as tk
from tkinter import ttk
from unicodedata import name
# ===== BST Node and BST Class =====
class Node:
    def __init__(self, name, phone=None):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
class BST:
    def __init__(self):
        self.root = None
    def insert(self, root, name, phone):
        if root is None:
            return Node(name, phone)
        if name < root.name:
            root.left = self.insert(root.left, name, phone)
        elif name > root.name:
            root.right = self.insert(root.right, name, phone)
        else:
            root.phone = phone
        return root
    def search(self, root, name):
        if root is None or root.name == name:
            return root
        if name < root.name:
            return self.search(root.left, name)
        else:
            return self.search(root.right, name)
    def find_min(self, root):
        current = root
        while current.left:
            current = current.left
        return current
    def delete(self, root, name):
        if root is None:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            # Node with one or no children
            if root.left is None:
                temp = root.right
                root = None
                return temp
            elif root.right is None:
                temp = root.left
                root = None
                return temp
        # Node with two children
            temp = self.find_min(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        return root
# ===== AVL Node and AVL Tree Class =====
class AVLNode:
    def __init__(self, name, phone):
        self.name = name
        self.phone = phone
        self.left = None
        self.right = None
        self.height = 1
class AVLTree:
    def __init__(self):
        self.root = None
    def height(self, node):
        return node.height if node else 0
    def get_balance(self, node):
        if not node:
            return 0
        return self.height(node.left) - self.height(node.right)
    def right_rotate(self, z):
        y = z.left
        T3 = y.right
        y.right = z
        z.left = T3
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y
    def left_rotate(self, z):
        y = z.right
        T2 = y.left
        y.left = z
        z.right = T2
        z.height = 1 + max(self.height(z.left), self.height(z.right))
        y.height = 1 + max(self.height(y.left), self.height(y.right))
        return y
    def insert(self, node, name, phone):
        if not node:
            return AVLNode(name, phone)
        if name < node.name:
            node.left = self.insert(node.left, name, phone)
        elif name > node.name:
            node.right = self.insert(node.right, name, phone)
        else:
            node.phone = phone
            return node
        node.height = 1 + max(self.height(node.left), self.height(node.right))
        balance = self.get_balance(node)
        # Rotations
        if balance > 1 and name < node.left.name:
            return self.right_rotate(node)
        if balance < -1 and name > node.right.name:
            return self.left_rotate(node)
        if balance > 1 and name > node.left.name:
            node.left = self.left_rotate(node.left)
            return self.right_rotate(node)
        if balance < -1 and name < node.right.name:
            node.right = self.right_rotate(node.right)
            return self.left_rotate(node)
        return node
    def min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current
    def delete(self, root, name):
        if not root:
            return root
        if name < root.name:
            root.left = self.delete(root.left, name)
        elif name > root.name:
            root.right = self.delete(root.right, name)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self.min_value_node(root.right)
            root.name = temp.name
            root.phone = temp.phone
            root.right = self.delete(root.right, temp.name)
        root.height = 1 + max(self.height(root.left), self.height(root.right))
        balance = self.get_balance(root)
        # Balancing
        if balance > 1 and self.get_balance(root.left) >= 0:
            return self.right_rotate(root)
        if balance > 1 and self.get_balance(root.left) < 0:
            root.left = self.left_rotate(root.left)
            return self.right_rotate(root)
        if balance < -1 and self.get_balance(root.right) <= 0:
            return self.left_rotate(root)
        if balance < -1 and self.get_balance(root.right) > 0:
            root.right = self.right_rotate(root.right)
            return self.left_rotate(root)
        return root
    def search(self, node, name):
        if node is None or node.name == name:
            return node
        if name < node.name:
            return self.search(node.left, name)
        else:
            return self.search(node.right, name)
        
# ===== Red-Black Tree Node and Tree Class =====
class RBNode:
    def __init__(self, name, phone, color=True):  # True for RED, False for BLACK
        self.name = name
        self.phone = phone
        self.color = color
        self.left = None
        self.right = None
        self.parent = None

class RedBlackTree:
    def __init__(self):
        self.NIL = RBNode(None, None, False)  # Sentinel node, BLACK
        self.root = self.NIL

    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.NIL:
            y.left.parent = x
        y.parent = x.parent
        if x.parent == self.NIL:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    def right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right != self.NIL:
            y.right.parent = x
        y.parent = x.parent
        if x.parent == self.NIL:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y
        y.right = x
        x.parent = y

    def insert_fixup(self, k):
        while k.parent.color == True:  # While parent is RED
            if k.parent == k.parent.parent.left:
                u = k.parent.parent.right  # Uncle
                if u.color == True:  # Case 1: Uncle is RED
                    k.parent.color = False
                    u.color = False
                    k.parent.parent.color = True
                    k = k.parent.parent
                else:
                    if k == k.parent.right:  # Case 2: k is right child
                        k = k.parent
                        self.left_rotate(k)
                    # Case 3: k is left child
                    k.parent.color = False
                    k.parent.parent.color = True
                    self.right_rotate(k.parent.parent)
            else:
                u = k.parent.parent.left  # Uncle
                if u.color == True:  # Case 1: Uncle is RED
                    k.parent.color = False
                    u.color = False
                    k.parent.parent.color = True
                    k = k.parent.parent
                else:
                    if k == k.parent.left:  # Case 2: k is left child
                        k = k.parent
                        self.right_rotate(k)
                    # Case 3: k is right child
                    k.parent.color = False
                    k.parent.parent.color = True
                    self.left_rotate(k.parent.parent)
            if k == self.root:
                break
        self.root.color = False  # Root is always BLACK

    def insert(self, name, phone):
        z = RBNode(name, phone, True)  # New node is RED
        z.left = self.NIL
        z.right = self.NIL
        y = self.NIL
        x = self.root
        while x != self.NIL:
            y = x
            if z.name < x.name:
                x = x.left
            else:
                x = x.right
        z.parent = y
        if y == self.NIL:
            self.root = z
        elif z.name < y.name:
            y.left = z
        else:
            y.right = z
        if z.parent == self.NIL:
            z.color = False  # Root is BLACK
            return
        if z.parent.parent == self.NIL:
            return
        self.insert_fixup(z)

    def search(self, name):
        x = self.root
        while x != self.NIL and name != x.name:
            if name < x.name:
                x = x.left
            else:
                x = x.right
        return x if x != self.NIL else None

    def transplant(self, u, v):
        if u.parent == self.NIL:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    def delete_fixup(self, x):
        while x != self.root and x.color == False:
            if x == x.parent.left:
                w = x.parent.right
                if w.color == True:
                    w.color = False
                    x.parent.color = True
                    self.left_rotate(x.parent)
                    w = x.parent.right
                if w.left.color == False and w.right.color == False:
                    w.color = True
                    x = x.parent
                else:
                    if w.right.color == False:
                        w.left.color = False
                        w.color = True
                        self.right_rotate(w)
                        w = x.parent.right
                    w.color = x.parent.color
                    x.parent.color = False
                    w.right.color = False
                    self.left_rotate(x.parent)
                    x = self.root
            else:
                w = x.parent.left
                if w.color == True:
                    w.color = False
                    x.parent.color = True
                    self.right_rotate(x.parent)
                    w = x.parent.left
                if w.right.color == False and w.left.color == False:
                    w.color = True
                    x = x.parent
                else:
                    if w.left.color == False:
                        w.right.color = False
                        w.color = True
                        self.left_rotate(w)
                        w = x.parent.left
                    w.color = x.parent.color
                    x.parent.color = False
                    w.left.color = False
                    self.right_rotate(x.parent)
                    x = self.root
        x.color = False

    def delete(self, name):
        z = self.search(name)
        if z is None:
            return
        y = z
        y_original_color = y.color
        if z.left == self.NIL:
            x = z.right
            self.transplant(z, z.right)
        elif z.right == self.NIL:
            x = z.left
            self.transplant(z, z.left)
        else:
            y = self.minimum(z.right)
            y_original_color = y.color
            x = y.right
            if y.parent == z:
                x.parent = y
            else:
                self.transplant(y, y.right)
                y.right = z.right
                y.right.parent = y
            self.transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color
        if y_original_color == False:
            self.delete_fixup(x)

    def minimum(self, x):
        while x.left != self.NIL:
            x = x.left
        return x


# ===== Benchmarking Function =====
def benchmark(n=10000, search_fraction=0.5, delete_count=100, verbose=True):
    # Generate test data
    names = [''.join(random.choices(string.ascii_lowercase, k=10)) for _ in range(n)]
    phones = [''.join(random.choices(string.digits, k=10)) for _ in range(n)]
    # --- BST benchmark ---
    bst = BST()
    bst.root = None
    # Insert
    start = time.time()
    for i in range(n):
        bst.root = bst.insert(bst.root, names[i], phones[i])
    bst_insert_time = time.time() - start
    # Search
    search_names = random.sample(names, int(n*search_fraction)) + ['notfoundname'] *int(n*(1 - search_fraction))
    start = time.time()
    found_bst = sum(1 for name in search_names if bst.search(bst.root, name))
    bst_search_time = time.time() - start
    # Delete
    delete_names = random.sample(names, delete_count)
    start = time.time()
    for name in delete_names:
        bst.root = bst.delete(bst.root, name)
    bst_delete_time = time.time() - start
    # --- RBT benchmark ---
    rbt = RedBlackTree()
    # Insert
    start = time.time()
    for i in range(n):
        rbt.insert(names[i], phones[i])
    rbt_insert_time = time.time() - start
    # Search
    start = time.time()
    found_rbt = sum(1 for name in search_names if rbt.search(name) is not None)
    rbt_search_time = time.time() - start
    # Delete
    start = time.time()
    for name in delete_names:
        rbt.delete(name)
    rbt_delete_time = time.time() - start
    # --- AVL benchmark ---
    avl = AVLTree()
    avl.root = None
    # Insert
    start = time.time()
    for i in range(n):
        avl.root = avl.insert(avl.root, names[i], phones[i])
    avl_insert_time = time.time() - start
    # Search
    start = time.time()
    found_avl = sum(1 for name in search_names if avl.search(avl.root, name))
    avl_search_time = time.time() - start
    # Delete
    start = time.time()
    for name in delete_names:
        avl.root = avl.delete(avl.root, name)
    avl_delete_time = time.time() - start
    # Prepare results
    results = {
    'Insertions': (bst_insert_time, avl_insert_time, rbt_insert_time),
    'Searches': (bst_search_time, avl_search_time, rbt_search_time),
    'Deletions': (bst_delete_time, avl_delete_time, rbt_delete_time),
    'Found In Search': (found_bst, found_avl, found_rbt)
    }
    if verbose:
        print(f"Benchmarking with {n} entries:\n")
        print("Operation BST Time (sec) AVL Time (sec) RBT Time (sec)")
        print("---------------------------------------------")
        print(f"Insertions: {bst_insert_time:.6f} {avl_insert_time:.6f} {rbt_insert_time:.6f}")
        print(f"Searches: {bst_search_time:.6f} {avl_search_time:.6f} {rbt_search_time:.6f}")
        print(f"Deletions: {bst_delete_time:.6f} {avl_delete_time:.6f} {rbt_delete_time:.6f}")
        print("---------------------------------------------")
        print(f"Contacts found in search:")
        print(f"BST: {found_bst} / {len(search_names)}")
        print(f"AVL: {found_avl} / {len(search_names)}")
        print(f"RBT: {found_rbt} / {len(search_names)}")
    return results
# ===== Tkinter GUI to show benchmark results =====
class BenchmarkApp:
    def __init__(self, master):
        self.master = master
        master.title("BST vs AVL vs RBT Benchmark")
        self.label = tk.Label(master, text="Run benchmark with 1000 entries?")
        self.label.pack(pady=5)
        self.run_btn = tk.Button(master, text="Run Benchmark",
        command=self.run_benchmark)
        self.run_btn.pack(pady=5)
        self.result_text = tk.Text(master, height=15, width=50)
        self.result_text.pack(pady=10)
        self.tree = ttk.Treeview(master, columns=("BST", "AVL", "RBT"), show='headings')
        self.tree.heading("BST", text="BST Time (s)")
        self.tree.heading("AVL", text="AVL Time (s)")
        self.tree.heading("RBT", text="RBT Time (s)")
        self.tree.pack(pady=10)
    def run_benchmark(self):
        self.result_text.delete(1.0, tk.END)
        results = benchmark(verbose=False) # silent print
        # Display text summary
        summary = (
        f"Insertion Time: BST: {results['Insertions'][0]:.6f}s, AVL: {results['Insertions'][1]:.6f}s, RBT: {results['Insertions'][2]:.6f}s\n"
        f"Search Time: BST: {results['Searches'][0]:.6f}s, AVL: {results['Searches'][1]:.6f}s, RBT: {results['Searches'][2]:.6f}s\n"
        f"Deletion Time: BST: {results['Deletions'][0]:.6f}s, AVL: {results['Deletions'][1]:.6f}s, RBT: {results['Deletions'][2]:.6f}s\n"
        f"Found in Search: BST: {results['Found In Search'][0]}, AVL: {results['Found In Search'][1]}, RBT: {results['Found In Search'][2]} out of 1000\n"
        )
        self.result_text.insert(tk.END, summary)
        # Clear previous treeview
        for row in self.tree.get_children():
            self.tree.delete(row)
        # Insert new data rows
        for op in ['Insertions', 'Searches', 'Deletions']:
            bst_time, avl_time, rbt_time = results[op]
            self.tree.insert('', tk.END, values=(f"{bst_time:.6f}", f"{avl_time:.6f}", f"{rbt_time:.6f}"), text=op)

# ===== Run the app =====
if __name__ == "__main__":
    root = tk.Tk()
    app = BenchmarkApp(root)
    root.mainloop()